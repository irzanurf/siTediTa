import pytesseract
# import mysql.connector
import sys
import os
from wand.image import Image
import PIL.Image
import re


import cv2
import numpy as np
# import os
# import pytesseract


def ocr_revisi(img_real_name):
    image = cv2.imread(img_real_name)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    # Remove horizontal lines
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (50,1))
    detect_horizontal = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel, iterations=2)
    cnts = cv2.findContours(detect_horizontal, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    for c in cnts:
        cv2.drawContours(thresh, [c], -1, (0,0,0), 2)

    # Remove vertical lines
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1,15))
    detect_vertical = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel, iterations=2)
    cnts = cv2.findContours(detect_vertical, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    for c in cnts:
        cv2.drawContours(thresh, [c], -1, (0,0,0), 3)

    # Dilate to connect text and remove dots
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10,1))
    dilate = cv2.dilate(thresh, kernel, iterations=2)
    cnts = cv2.findContours(dilate, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    for c in cnts:
        area = cv2.contourArea(c)
        if area < 500:
            cv2.drawContours(dilate, [c], -1, (0,0,0), -1)

    # Bitwise-and to reconstruct image
    result = cv2.bitwise_and(image, image, mask=dilate)
    result[dilate==0] = (255,255,255)

    # OCR
    data = pytesseract.image_to_string(result, lang='eng',config='--psm 6')
    return data

def ocr_perbaris(img_real_name):
    img_real = cv2.imread(img_real_name)
    scale_percent = 60 # percent of original size
    width = int(img_real.shape[1] * scale_percent / 100)
    height = int(img_real.shape[0] * scale_percent / 100)
    dim = (width, height)
    # resize image
    img = cv2.resize(img_real, dim, interpolation = cv2.INTER_AREA)

    # convert to gray
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # threshold the grayscale image
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    # use morphology erode to blur horizontally
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (300, 3))
    morph = cv2.morphologyEx(thresh, cv2.MORPH_DILATE, kernel)



    # find contours
    cntrs = cv2.findContours(morph, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cntrs = cntrs[0] if len(cntrs) == 2 else cntrs[1]

    # find the topmost box
    ythresh = 1000
    for c in cntrs:
        box = cv2.boundingRect(c)
        x,y,w,h = box
        if y < ythresh:
            topbox = box
            ythresh = y

    # Draw contours excluding the topmost box
    i=1
    result = img.copy()
    for c in cntrs:
        box = cv2.boundingRect(cntrs[(len(cntrs)-i)])
        x,y,w,h = box
        cv2.rectangle(result, (x, y), (x+w, y+h), (0, 0, 255), 2)
        cv2.imwrite(str("./image_box/")+str(i)+".jpg",img[y:y+h,x:x+w])
        tess_cfg = '--psm 6 --oem 1 --hocr ' #or tess_cfg = '-psm 6 -oem 1 -hocr'
        hasilnya = pytesseract.image_to_string((img[y:y+h,x:x+w]), lang="eng",config = tess_cfg)
        print(hasilnya)
        # print(h)
        i=i+1

khusus_filename = "./pdf/3.pdf"


outfile = "./result.txt"
f = open(outfile, "w")
f.write("")
f.close()


with(Image(filename=khusus_filename, resolution=120)) as source:
    filename=khusus_filename
    global images
    images = source.sequence
    pages = len(images)
    for i in range(pages):
        n = i + 1
        newfilename = filename[:-4] + str(n) + '.jpeg'
        Image(images[i]).save(filename=newfilename)

        # print(ocr_revisi(newfilename))

        # Creating a text file to write the output

        # Open the file in append mode so that
        # All contents of all images are added to the same file
        f = open(outfile, "a")

        # pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
        # Recognize the text as string in image using pytesserct

        #text = text.replace('-\n', '')
        hasil_ocr_revisi = str(ocr_revisi(newfilename)).replace('-\n', '')
        print(hasil_ocr_revisi)
        f.write(str(hasil_ocr_revisi))

    for i in range(pages):
        n = i + 1
        newfilename = filename[:-4] + str(n) + '.jpeg'
        os.remove(newfilename)

f.close()

################################################################################
################################################################################
################################################################################
text_as_string = open('result.txt', 'r').read()
text_arrays = text_as_string.split('\n')

start_judul_index  = 0

###PROSES AMBIL JUDUL
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Judul' in text_array:
        start_judul_index = index
        break
    index+=1

index = start_judul_index
result_judul = ""

for x in range(10):
    if 'Ketua Pelaksana' in text_arrays[index]:
        start_judul_index = index
        break
    result_judul += text_arrays[index]
    result_judul += ' '
    index+=1
result_judul = result_judul.replace('Judul','')


###########################################
start_abstrak_index  = 0
index = 0
is_daftar_isi = True
for text_array in text_arrays:
    # print(text_array)
    if 'RINGKASAN' in text_array:
        if is_daftar_isi:
            is_daftar_isi = False
        else:
            start_abstrak_index = index
            break


    index+=1

index = start_abstrak_index+1
result_abstrak = ""

for x in range(100):
    if 'Kata kunci' in text_arrays[index]:
        start_abstrak_index = index
        break
    result_abstrak += text_arrays[index]
    result_abstrak += ' '

    index+=1

#######################################################
###PROSES AMBIL SUMBER DANA
start_sumber_dana_index  = 0
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Sumber dana' in text_array:
        start_sumber_dana_index = index
        break
    index+=1

index = start_sumber_dana_index
result_sumber_dana_array = text_arrays[start_sumber_dana_index].split(',');
r_mentah_sumber_dana = ''
if len(result_sumber_dana_array) > 1:
    index = 0
    for x in range(10):
        if 'Sumber dana' in result_sumber_dana_array[index]:
            start_sumber_dana_index = index
            break
        index += 1

    r_mentah_sumber_dana = result_sumber_dana_array[start_sumber_dana_index]
else:
    r_mentah_sumber_dana = result_sumber_dana_array[0]

result_sumber_dana = ''
if len(r_mentah_sumber_dana.split(":")) > 1:
    result_sumber_dana = r_mentah_sumber_dana.split(":")[1]
else:
    result_sumber_dana = r_mentah_sumber_dana


#######################################################
###PROSES AMBIL BIAYA PENGABDIAN
start_biaya_index  = 0
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Biaya Pengabdian' in text_array:
        start_biaya_index = index
        break
    index+=1

index = start_biaya_index
result_biaya_array = text_arrays[start_biaya_index].split(',');
r_mentah_biaya = ''
if len(result_biaya_array) > 1:
    index = 0
    for x in range(10):
        if 'Biaya Pengabdian' in result_biaya_array[index]:
            start_biaya_index = index
            break
        index += 1

    r_mentah_biaya = result_biaya_array[start_biaya_index]
else:
    r_mentah_biaya = result_biaya_array[0]

result_biaya = ''
if len(r_mentah_biaya.split(":")) > 1:
    result_biaya = r_mentah_biaya.split(":")[1]
else:
    result_biaya = r_mentah_biaya

#######################################################
###PROSES AMBIL LAMA PENGABDIAN
start_lama_pengabdian_index  = 0
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Lama Pengabdian' in text_array:
        start_lama_pengabdian_index = index
        break
    index+=1

index = start_lama_pengabdian_index
result_lama_pengabdian_array = text_arrays[start_lama_pengabdian_index].split(',');
r_mentah_lama_pengabdian = ''
if len(result_lama_pengabdian_array) > 1:
    index = 0
    for x in range(10):
        if 'Lama Pengabdian' in result_lama_pengabdian_array[index]:
            start_lama_pengabdian_index = index
            break
        index += 1

    r_mentah_lama_pengabdian = result_lama_pengabdian_array[start_lama_pengabdian_index].replace('Lama Pengabdian','')
else:
    r_mentah_lama_pengabdian = result_lama_pengabdian_array[0].replace('Lama Pengabdian','')

result_lama_pengabdian = ''
if len(r_mentah_lama_pengabdian.split(":")) > 1:
    result_lama_pengabdian = r_mentah_lama_pengabdian.split(":")[1]
else:
    result_lama_pengabdian = r_mentah_lama_pengabdian
# print(result_lama_pengabdian)


#######################################################
###PROSES AMBIL LOKASI MITRA
start_lokasi_index  = 0
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Lokasi Mitra' in text_array:
        start_lokasi_index = index
        break



    index+=1

index = start_lokasi_index+1
result_lokasi_s = ""
result_lokasi = ""
for x in range(100):
    if 'Luaran' in text_arrays[index]:
        start_lokasi_index = index
        break
    result_lokasi_s += text_arrays[index]
    result_lokasi_s += ' '

    index+=1


for v in result_lokasi_s.split(" "):
    if len(v) > 2:
        result_lokasi += str(v)+' '

#######################################################
###PROSES AMBIL ANGGOTA DOSEN
start_anggota_dosen_index  = 0
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Nama Anggota' in text_array:
        start_anggota_dosen_index = index
        break



    index+=1

index = start_anggota_dosen_index
result_anggota_dosen_s = []
result_anggota_dosen = ""
for x in range(100):
    if 'Nama Anggota' in text_arrays[index]:
        pass
    else:
        start_anggota_dosen_index = index
        break
    result_anggota_dosen_s.append(''.join(i for i in text_arrays[index].replace('Nama Anggota','') if not i.isdigit()))

    index+=1


#######################################################
###PROSES AMBIL ANGGOTA MAHASISWA
print("text_arrays")
start_anggota_mahasiswa_index  = 0
index = 0
for text_array in text_arrays:
    # print(text_array)
    if 'Mahasiswa terlibat' in text_array:
        start_anggota_mahasiswa_index = index
        break



    index+=1
print("text_arrays")
index = start_anggota_mahasiswa_index
result_anggota_mahasiswa_s = []
result_anggota_mahasiswa = ""
for x in range(100):
    print("text_arrays")
    print(text_arrays[index])
    if 'Lokasi Mitra' in text_arrays[index]:
        start_anggota_mahasiswa_index = index
        break
    result_anggota_mahasiswa_s.append(''.join(i for i in text_arrays[index].replace('Nama Anggota','').replace('Mahasiswa terlibat','') if not i.isdigit()))

    index+=1
# result_anggota_mahasiswa = result_anggota_mahasiswa_s.replace('Mahasiswa terlibat','').split(',')


print("Jenis Pengabdian : ")
print(" ")
print("\n")

print("Judul Pengabdian : ")
print(result_judul.strip())
print("\n")

print("Abstrak : ")
print(result_abstrak.strip())
print("\n")

print("Lokasi : ")
print(result_lokasi)
print("\n")

print("Lama Pelaksanaan : ")
print(result_lama_pengabdian.strip())
print("\n")

print("Biaya : ")
print(result_biaya)
print("\n")


print("Sumber Dana : ")
print(result_sumber_dana.strip())
print("\n")


print("Anggota Dosen : ")
for dosen in result_anggota_dosen_s:
    print(dosen.strip())
print("\n")

print("Anggota Mahasiswa : ")
for mhs in result_anggota_mahasiswa_s:
    print(mhs.strip())
print("\n")
